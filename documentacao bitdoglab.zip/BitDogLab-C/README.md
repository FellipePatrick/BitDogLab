# BitDogLab em C

Este repositório contém diversos projetos para o controle dos componentes da BitDogLab na linguagem C, usando a Pico SDK.
