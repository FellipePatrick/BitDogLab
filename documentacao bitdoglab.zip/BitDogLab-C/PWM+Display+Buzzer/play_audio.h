extern int main_audio();
extern void setup_audio();